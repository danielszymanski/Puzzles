﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Laboratory1
{
    public class SudokuState : State
    {


        public const int SMALL_GRID_SIZE = 3;

        public const int GRID_SIZE = SMALL_GRID_SIZE * SMALL_GRID_SIZE;


        private string id;

        private int[,] table;

        public int[,] Table
        {
            get { return this.table; }
            set { this.table = value; }
        }


        public override string ID
        {
            get { return this.id; }
        }


        public void Print()
        {
        }

        public override double ComputeHeuristicGrade()
        {
            throw new NotImplementedException();
        }



        public SudokuState(string sudokuPattern)
            : base()
        {
            if (sudokuPattern.Length != GRID_SIZE * GRID_SIZE)
            {
                throw new ArgumentException(" SudokuSring posiada niewlasciwa dlugosc .");
            }
            // utworzenie id
            this.id = sudokuPattern;
            // stworzenie i wypelnienie wewnetrzej tablicy przechowujacej stan sudoku
            this.table = new int[GRID_SIZE, GRID_SIZE];

            for (int i = 0; i < GRID_SIZE; ++i)
            {
                for (int j = 0; j < GRID_SIZE; ++j)
                {
                    this.table[i, j] = sudokuPattern[i * GRID_SIZE + j] - 48;
                }
            }

            // obliczenie heurystyki
            this.h = ComputeHeuristicGrade();
        }

        public SudokuState(SudokuState parent, int newValue, int x, int y)
            : base(parent)
        {
            this.table = new int[GRID_SIZE, GRID_SIZE];
            // Skopiowanie stanu sudoku do nowej tabeli
            Array.Copy(parent.table, this.table, this.table.Length);
            // Ustawienie nowej wartosci w wybranym polu sudoku
            this.table[x, y] = newValue;

            // Utworzenie nowego id odpowiadajacemu aktualnemu stanowi planszy
            StringBuilder builder = new StringBuilder(parent.id);
            builder[x * GRID_SIZE + y] = (char)(newValue + 48);
            this.id = builder.ToString();

            this.h = ComputeHeuristicGrade();
        }
    }
} 
